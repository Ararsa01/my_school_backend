const mongoose = require('mongoose');

const studentSchema = new mongoose.Schema({
  name: String,
  photo: String,        // path to uploaded photo
  achievement: String,  // optional description
  rank: Number          // optional rank in class/school
});

module.exports = mongoose.model('Student', studentSchema);