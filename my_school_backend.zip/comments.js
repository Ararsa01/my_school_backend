const router = require('express').Router();
const Comment = require('../models/Comment');

// Add comment
router.post('/', async (req, res) => {
    const newComment = new Comment(req.body);
    try {
        const saved = await newComment.save();
        res.status(200).json(saved);
    } catch(err) {
        res.status(500).json(err);
    }
});

// Get all comments
router.get('/', async (req, res) => {
    try {
        const comments = await Comment.find().sort({date: -1});
        res.status(200).json(comments);
    } catch(err) {
        res.status(500).json(err);
    }
});

module.exports = router;