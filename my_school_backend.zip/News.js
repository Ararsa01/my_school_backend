const mongoose = require('mongoose');

const newsSchema = new mongoose.Schema({
  title: String,
  description: String,
  photo: String, // URL/path of uploaded photo
  video: String, // URL/path of uploaded video
  date: { type: Date, default: Date.now }
});

module.exports = mongoose.model('News', newsSchema);