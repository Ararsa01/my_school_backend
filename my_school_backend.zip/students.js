const router = require('express').Router();
const Student = require('../models/Student');
const multer = require('multer');

// Configure multer for photo uploads
const storage = multer.diskStorage({
  destination: function(req, file, cb){
    cb(null, 'uploads/');
  },
  filename: function(req, file, cb){
    cb(null, Date.now() + '-' + file.originalname);
  }
});
const upload = multer({ storage: storage });

// Add a new student
router.post('/', upload.single('photo'), async (req, res) => {
  const newStudent = new Student({
    name: req.body.name,
    achievement: req.body.achievement,
    rank: req.body.rank,
    photo: req.file ? req.file.path : ''
  });

  try {
    const savedStudent = await newStudent.save();
    res.status(200).json(savedStudent);
  } catch(err) {
    res.status(500).json({ error: 'Failed to add student', details: err });
  }
});

// Get all students, sorted by rank
router.get('/', async (req, res) => {
  try {
    const students = await Student.find().sort({ rank: 1 });
    res.status(200).json(students);
  } catch(err) {
    res.status(500).json({ error: 'Failed to fetch students', details: err });
  }
});

module.exports = router;