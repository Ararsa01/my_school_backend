const router = require('express').Router();
const Activity = require('../models/Activity');
const multer = require('multer');

// Configure multer for file uploads (photos/videos)
const storage = multer.diskStorage({
  destination: function(req, file, cb){
    cb(null, 'uploads/'); // folder to store uploaded files
  },
  filename: function(req, file, cb){
    cb(null, Date.now() + '-' + file.originalname); // unique filenames
  }
});

const upload = multer({ storage: storage });

// Add new activity
// Accepts 'photo' and 'video' files
router.post('/', upload.fields([{ name: 'photo' }, { name: 'video' }]), async (req, res) => {
  const newActivity = new Activity({
    title: req.body.title,
    description: req.body.description,
    photo: req.files.photo ? req.files.photo[0].path : '',
    video: req.files.video ? req.files.video[0].path : ''
  });

  try {
    const savedActivity = await newActivity.save();
    res.status(200).json(savedActivity);
  } catch(err) {
    res.status(500).json({ error: 'Failed to add activity', details: err });
  }
});

// Get all activities
router.get('/', async (req, res) => {
  try {
    const activities = await Activity.find().sort({ date: -1 });
    res.status(200).json(activities);
  } catch(err) {
    res.status(500).json({ error: 'Failed to fetch activities', details: err });
  }
});

module.exports = router;